﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class AutomovelModel
    {
        public string  Motorista { get; set; }
        public string Modelo  { get; set; }
        public int Ano { get; set; }
        public string Placa { get; set; }

        public AutomovelModel()
        {
            Modelo = "Maserati";
            Motorista = "Louivi thon";
            Placa = "ipo-562";
            Ano = 2020;
        }

        public static AutomovelModel CriarCarro()
        {
            var Automovel = new AutomovelModel();
            Automovel.Modelo = "Civic";
            return Automovel;
        }
        public static List<AutomovelModel> CriarLista()
        {
            var lista = new List<AutomovelModel>();

            lista.Add(new AutomovelModel() { Modelo = "Audi", Motorista = "luiz fernandes", Placa = "CVB-789", Ano = 1998 });
            lista.Add(new AutomovelModel() { Modelo = "Bentley", Motorista = "Arthur Vinicius", Placa = "MLÇ-789", Ano = 1997 });
            lista.Add(new AutomovelModel() { Modelo = "Fiat", Motorista = "Vinicius da Silva", Placa = "CVB-456", Ano = 1996 });

            
            return lista;
        }
    }
}
